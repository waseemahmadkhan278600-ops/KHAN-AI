package com.waseemkhan.aiguruji

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private data class ChatMessage(val role: String, val text: String)

class ChatViewModel : ViewModel() {
    var messages by mutableStateOf(listOf(ChatMessage("model", "Namaste! 👋 Main Waseem Khan AI Guru Ji hoon. Aap Hindi, English ya kisi bhi supported language mein likh sakte hain.")))
        private set
    var input by mutableStateOf("")
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        input = ""
        error = null
        messages = messages + ChatMessage("user", text)
        loading = true
        viewModelScope.launch {
            try {
                val answer = GeminiClient.generate(messages)
                messages = messages + ChatMessage("model", answer)
            } catch (e: Exception) {
                error = e.message ?: "Something went wrong"
            } finally {
                loading = false
            }
        }
    }

    fun newChat() {
        messages = listOf(ChatMessage("model", "Nayi chat shuru ho gayi. 😊 Aap kya poochna chahte hain?"))
        error = null
        input = ""
    }
}

private object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"

    suspend fun generate(history: List<ChatMessage>): String = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        require(apiKey.isNotEmpty()) {
            "Gemini API key set nahi hai. local.properties mein GEMINI_API_KEY=YOUR_KEY add karein."
        }
        val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }
        val contents = JSONArray()
        history.takeLast(30).forEach { message ->
            val role = if (message.role == "model") "model" else "user"
            contents.put(JSONObject().apply {
                put("role", role)
                put("parts", JSONArray().put(JSONObject().put("text", message.text)))
            })
        }

        val system = """
            You are Waseem Khan AI Guru Ji, a helpful multilingual AI assistant.
            Always understand the user's language and answer in the same language unless the user asks for another language.
            Be clear, respectful, practical and concise. Support Hindi, English, Hinglish and other languages.
            Do not claim to have abilities you do not have. If a request needs an API, account, permission or device access, explain the next step.
        """.trimIndent()

        val body = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", system)))
            })
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 2048)
            })
        }

        val request = okhttp3.Request.Builder()
            .url("$BASE_URL$model:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody(okhttp3.MediaType.get("application/json")))
            .build()

        okhttp3.OkHttpClient().newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Gemini API error ${response.code}: ${extractError(raw)}")
            }
            val json = JSONObject(raw)
            val candidates = json.optJSONArray("candidates")
                ?: throw IllegalStateException("Gemini ne response nahi diya.")
            val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw IllegalStateException("Empty Gemini response.")
            buildString {
                for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
            }.trim().ifBlank { "Mujhe abhi koi text response nahi mila." }
        }
    }

    private fun extractError(raw: String): String = try {
        JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty().ifBlank { raw.take(300) }
    } catch (_: Exception) { raw.take(300) }

    private fun String.toRequestBody(mediaType: okhttp3.MediaType) =
        okhttp3.RequestBody.create(mediaType, this)
}

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { AIGuruJiApp(onSpeak = { speak(it) }) }
    }

    private fun speak(text: String) {
        val locale = if (text.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale.getDefault()
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ai_guru_reply")
    }

    override fun onInit(status: Int) {}

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); super.onDestroy()
    }
}

@Composable
private fun AIGuruJiApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val vm: ChatViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val listState = rememberLazyListState()
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) vm.input = spoken
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeech(context, speechLauncher)
    }

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF6A36C9),
        secondary = Color(0xFF8B5CF6),
        background = Color(0xFFF7F3FF)
    )) {
        Scaffold(
            containerColor = Color(0xFFF7F3FF),
            topBar = {
                Surface(shadowElevation = 3.dp, color = Color.White) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painterResource(R.drawable.ai_guru_image),
                            contentDescription = "Waseem Khan AI Guru Ji",
                            modifier = Modifier.size(46.dp).clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Waseem Khan AI Guru Ji", fontWeight = FontWeight.Bold)
                            Text("Multilingual AI Assistant", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                        }
                        IconButton(onClick = vm::newChat) { Icon(Icons.Default.Add, "New chat") }
                    }
                }
            },
            bottomBar = {
                Surface(shadowElevation = 10.dp, color = Color.White) {
                    Row(
                        modifier = Modifier.fillMaxWidth().imePadding().padding(10.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        OutlinedTextField(
                            value = vm.input,
                            onValueChange = { vm.input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Message likhiye…") },
                            maxLines = 5,
                            shape = RoundedCornerShape(22.dp),
                            trailingIcon = {
                                IconButton(onClick = {
                                    if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                        launchSpeech(context, speechLauncher)
                                    } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }) { Icon(Icons.Default.Mic, "Voice input") }
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        FloatingActionButton(onClick = vm::send, containerColor = Color(0xFF6A36C9)) {
                            Icon(Icons.Default.Send, "Send", tint = Color.White)
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().weight(1f),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(vm.messages) { message ->
                        MessageBubble(message, onSpeak)
                    }
                    if (vm.loading) item {
                        Text("AI soch raha hai…", color = Color.Gray, modifier = Modifier.padding(8.dp))
                    }
                    vm.error?.let { error -> item { Text(error, color = MaterialTheme.colorScheme.error) } }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage, onSpeak: (String) -> Unit) {
    val user = message.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (user) Color(0xFFE6D9FF) else Color.White,
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 1.dp,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(Modifier.padding(13.dp)) {
                Text(message.text)
                if (!user) {
                    IconButton(onClick = { onSpeak(message.text) }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.VolumeUp, "Speak", tint = Color(0xFF6A36C9))
                    }
                }
            }
        }
    }
}

private fun launchSpeech(
    context: android.content.Context,
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye…")
    }
    try { launcher.launch(intent) } catch (_: Exception) { }
}

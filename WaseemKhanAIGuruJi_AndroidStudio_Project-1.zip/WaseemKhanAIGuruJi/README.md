# 🤖 Waseem Khan AI Guru Ji

Android Studio source project for a multilingual AI chat app inspired by the provided branding image.

## Included
- ChatGPT-style chat screen
- Hindi, English, Hinglish and other language conversations
- Prompt instructs Gemini to reply in the user's language
- Voice input using Android SpeechRecognizer
- Read-aloud button using Android Text-to-Speech
- Gemini API integration point
- Provided image used as app branding/icon
- Android minSdk 24 / targetSdk 35

## Add Gemini API key
1. Get a Gemini API key from Google AI Studio.
2. Open `local.properties` in the project root.
3. Add:

```properties
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
GEMINI_MODEL=gemini-3.8-flash
```

Do not commit a real API key to GitHub. A key embedded in a mobile APK can be extracted. For production, put the Gemini call behind your own backend.

## Build
Open the folder in Android Studio and let Gradle sync. If Android Studio asks for a Gradle distribution, use the project's configured Gradle version (8.11.1). Then choose:

**Build → Build APK(s)**

The debug APK is normally produced at:

`app/build/outputs/apk/debug/app-debug.apk`

## Notes
- Voice input depends on the speech recognition service installed on the Android phone.
- Text-to-speech uses the phone's installed TTS engine/language packs.
- The Gemini API endpoint is the official `generateContent` REST endpoint.
